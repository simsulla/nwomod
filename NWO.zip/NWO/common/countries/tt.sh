cp Saudi\ Arabia.txt Gulf\ Cooperation\ Council.txt 
cp Guatemala.txt Central\ American\ Union.txt 
cp Kenya.txt East\ African\ Federation.txt 
cp France.txt Europena\ Union.txt 
cp Guyana.txt CARICOM.txt 
cp Ethiopia.txt African\ Union.txt 
cp Nigeria.txt ECOWAS.txt 
cp Gabon.txt ECCAS.txt 
cp Bophuthatswana.txt Southern\ African\ Development\ Community.txt 
cp Uruguay.txt Union\ of\ South\ American\ Nations.txt 
cp Uruguay.txt Mercosur.txt 
cp Peru.txt Andean\ Community.txt 
cp Egypt.txt Arab\ League.txt 
cp USA.txt NAFTA.txt 
cp India.txt SAARC.txt 
cp Australia.txt Pacific\ Islands\ Federation.txt 
cp Russia.txt Eurasian\ Economic\ Community.txt 
cp Ottoman\ Empire.txt Turkic\ Council.txt 
cp Persia.txt Economic\ Cooperation\ Organization.txt 
cp Morocco.txt Arab\ Maghreb\ Union.txt 
cp Indonesia.txt ASEAN.txt
cp Nicaragua.txt Central\ American\ Integration\ System.txt
